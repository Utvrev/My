const global = {
    ownerId: [7349091777],
    botName: "SaxiosTeam",
    botToken: "8022691718:AAGT3xWaPyTNkGGwfAPnRy7cPm3ByO8Kmz8",
    channelLink: "https://t.me/SaxiosStresser",
    preview: 'https://files.catbox.moe/hw20c0.webp'
}

module.exports = global;